import socket
import sys
HOST = sys.argv[1]    # The remote host
PORT = sys.argv[2] 

def main():
    
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect((HOST, int(PORT)))
    s.settimeout(1)
    comment = raw_input("Escriu el que vols enviar: ")
    s.send(comment)
    while(True):
        try :
            data, addr = s.recvfrom(1024)
            print 'Received', repr(data) , 'From', repr(addr)
        except:

            comment = raw_input("Escriu el que vols enviar: ")
            if comment == "exit":
                s.close()
                break;
            s.send(comment)
        


if __name__ == "__main__":
    main()

