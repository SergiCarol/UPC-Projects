#ifndef __CONTROLSEM_H
#define __CONTROLSEM_H



void controlsem_init();
void tick_monitor(void);
void tick_semaphore(void);

#endif