#ifndef __MODULATOR_H
#define __MODULATOR_H
#include <stdbool.h>
void modulator_init(void);
void modulator_set(bool l);

#endif
