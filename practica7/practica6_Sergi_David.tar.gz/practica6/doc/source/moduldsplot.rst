Modul dsplot
============

Contingut
---------

El modul *dsplot* serà l'encarregat de imprimir l'informació del sensor a pantalla. Concretament, farà una gràfica.

Aquest modul es molt curt, però s'ha de tenir en compte que es molt important, ja que sense aquesta part l'usuari no podria veure l'informació de manera clara a pantalla (Hi ha moltíssimes dades a la vegada).


Classes i funcions associades
-----------------------------

.. automodule:: dsplot
	:members:
