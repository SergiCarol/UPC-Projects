Modul dataset
=============

Contingut
---------

El modul dataset será l'encarregat de contenir la classe *dataset* i la classe *Outofexception*

Classes i funcions associades
-----------------------------

.. automodule:: dataset
	:members:
