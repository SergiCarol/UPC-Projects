Modul explora
=============

Continguts
----------

El modul explora es l'encarregat de "ajuntar" tots els mòduls que hem realitzat per separat. 

Tal com es pot observar si es miren els codis font, el modul explora no té extensió *.py*, ja que no feia falta.

Per a executar aquesta aplicació es fa en la terminal, escrivint la següent comanda:

.. code-block:: python

   $ ./explora -v (web que vols) -s (sensors que vols) -d dd/mm/aaaa

Opcional:

.. code-block:: python

   $ ./explora -v (web que vols) -s (sensors que vols) -d dd/mm/aaaa -f dd/mm/aaaa

T'agafa les dades d'un dia (-d) fins a un altre (-f).

Classes i funcions associades
-----------------------------

**Aquest modul no té cap classe o funció associada.**




