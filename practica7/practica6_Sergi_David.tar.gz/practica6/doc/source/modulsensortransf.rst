Modul sensortransf
==================

Contingut
---------

Aquest modul solament exporta una funció capaç d'aplicar la transformació escaient a un DataSet per tal d'obtenir els valors de les temperatures.

S'ha de tenir en compte que les dades que es llegeixen dels sensors no son pròpiament temperatures. Cal aplicar les transformacions lineals que allí s'expliquen, diferents per a cada sensor, per tal d'obtenir-ne les temperatures.

Classes i funcions associades
-----------------------------

.. automodule:: sensortransf
	:members:
