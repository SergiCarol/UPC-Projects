Modul datafetcher
=================

Contingut
---------

El modul datafetcher será l'encarregat de contenir la classe *dataset* i la classe *Outofexception*

Classes i funcions associades
-----------------------------

.. automodule:: datafetcher
	:members:
