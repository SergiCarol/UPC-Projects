.. Documentació de la practica 6, creada amb
   sphinx-quickstart el Dill Abr 29 08:30:24 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Practica 6: Tractament de dades de sensors
==========================================

Continguts:

.. toctree::
   :maxdepth: 2

   introduccio
   moduldataset
   moduldatafetcher
   moduldsplot
   modulsensortransf
   modulexplora



Index
=====

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

