#!/bin/bash

ls -S $1 | head -n 2