#!/bin/bash

find $HOME -atime -90
