#!/bin/bash

ls $1 -h -l | cut -d " " -f  5-5
