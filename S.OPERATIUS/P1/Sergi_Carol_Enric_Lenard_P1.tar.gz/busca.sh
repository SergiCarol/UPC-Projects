#!/bin/bash

find $HOME|grep [$1]*
