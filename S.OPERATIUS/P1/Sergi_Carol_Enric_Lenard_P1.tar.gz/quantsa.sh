#!/bin/bash

ls $1|grep 'a'|wc -l
