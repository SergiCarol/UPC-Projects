===========
Instruction
===========

.. automodule:: instruction
   :members:


.. include:: testinstruction.rst
