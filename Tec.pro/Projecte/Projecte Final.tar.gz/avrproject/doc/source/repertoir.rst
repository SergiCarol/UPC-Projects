=========
Repertoir
=========

.. automodule:: repertoir
   :members:

.. include:: testrepetoir.rst
