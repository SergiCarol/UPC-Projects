=========
Bitvector
=========

.. automodule:: bitvec
   :members:

.. include:: testbitvec.rst
