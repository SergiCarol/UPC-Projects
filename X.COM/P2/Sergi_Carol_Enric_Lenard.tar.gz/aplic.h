#ifndef __APLIC_H
#define __APLIC_H

#include <pbn.h>
#include "lan.h"
#include <avr/interrupt.h>

#endif