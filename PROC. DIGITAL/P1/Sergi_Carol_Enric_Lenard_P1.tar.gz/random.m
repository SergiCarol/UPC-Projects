
function random(tf,Fm,n)
	% X1
	% Creem Fm numeros aleatoris de -1 a 1
	x1 = randn(Fm,1);

	%x2
	% Passem els numeros anteriors a 0 i 1
	x2=x1;
	x2=x2>=0;


	%X3
	% Creem un vector de llargada n nomes d'uns
	c=ones(n,1);
	% Numero d'iteracions
	k=2^n -1;
	% Creem un vector tot de 0's en el qual hi ficarem els valors
	x3=zeros(k,1);

	if (n==16)
		for i = 1:k
			% Fem les corresponents xors
			d=xor(c(end),c(end-2));
			d=xor(d,c(end-3));
			d=xor(d,c(end-5));
			% El valor resultant el guardem a x3
			x3(i)=d;
			% Creem el nou vector
			c=[d;c(1:end-1)];
		end
	elseif (n==10)
		for i = 1:k
			% En el cas de que n sigui 10 nomes fem la xor per el bit 10 i el 7.
			d=xor(c(end),c(end-3));
			x3(i)=d;
			c=[d;c(1:end-1)];
		end			
	end

	
	% Reproduim el sons

	play_so(x1,Fm),pause(1),play_so(x2,Fm),pause(1),play_so(x3,Fm)


%Conclusions
% Hem trobat que la Fm que m´es s'aproxima a obtenir soroll blanc es la de 48e3 Hz amb una n de 16, on n es la llargada del vector en bits.
%En el cas de que utilitzem una n de 10 creiem que el valor de Fm que mes s'aproxima al so del soroll blanc es de 24e3.







