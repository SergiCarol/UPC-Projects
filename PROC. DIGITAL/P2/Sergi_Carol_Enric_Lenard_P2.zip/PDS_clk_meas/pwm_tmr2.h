#ifndef _PWM_TMR2_
#define _PWM_TMR2_

void setup_pwm_tmr2(uint8_t pwm_out);// pwm output values:3,11
void set_pwm_tmr2(uint8_t value);

#endif
