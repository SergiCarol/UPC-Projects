#include <inttypes.h>
#include <avr/io.h>
#include "tmr0.h"

void setup_tmr1(uint16_t ocr1a,uint16_t tmr1_pre){
  TCCR1A=0x00;//CTC mode: TOP=OCRA 
  TIMSK1=0x02;//Bit 1 – OCIE1A: Timer/Counter0 Output Compare Match A Interrupt Enable
  OCR1A=ocr1a;//TOP value

  //tmr1_pre 1,default=8,64,256,1024
  switch (tmr1_pre){
  case 1:TCCR1B=1+8;break;
  case 8:TCCR1B=2+8;break;
  case 64:TCCR1B=3+8;break;
  case 256:TCCR1B=4+8;break;
  case 1024:TCCR1B=5+8;break;
  default:TCCR1B=2+8;break;
  }
}
