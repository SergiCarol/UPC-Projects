#include <avr/interrupt.h>
#include "adc.h"
#include "tmr0.h"
#include "pwm_tmr2.h"
#include <stdio.h>
#include <stdbool.h> 
#include "serial.h"

/********************************************
                Clock measurement
---------------------------------------------
This program takes samples from the analog
input A5 of the Ardiuno UNO Board.
The conversion time is 13/fadc_clk, fadc_clk=16e6/adc_pre.

With the 8 most significant bits
it updates the PWM output at terminal ~3 or ~11.

An interrupt is activated each 50us (ocr0a=99, tmr0_pre=8)

The digital output PD4 is set to '1'
at the beginning of the ISR
and to '0' at the end.

26 September 2014
*********************************************/

#define marge 10
#define inter_freq 20000
#define inici 790
#define final 810

static int uart_putchar(char c, FILE *stream);
static FILE mystdout = FDEV_SETUP_STREAM(uart_putchar, NULL,_FDEV_SETUP_WRITE);
static int uart_putchar(char c, FILE *stream){
  if (c == '\n')
    uart_putchar('\r', stream);
  loop_until_bit_is_set(UCSR0A, UDRE0);
  UDR0 = c;
  return 0;
}

typedef enum {positiu, negatiu} state;
static state estat=0; 
static uint16_t i=0;
static int comptador=0;
static uint16_t clocks=0;
static uint16_t minim=0xFFFF;
static uint32_t frequencia=0;
static uint32_t diferencia=0;

void setup(){
  setup_ADC(5,5,16);
  setup_tmr1(790,1);
  setup_pwm_tmr2(11);
  DDRD |=(1<<DDD4);//pin 4 Arduino as an output. It shows sampling period (period) and ISR execution time (pulse wide)
  serial_open();
  sei();
}

int main(void){
  setup();
  stdout = &mystdout;
  while(1);
}

ISR(TIMER1_COMPA_vect){
  PORTD |= (1<<PD4);
  uint8_t value=read8_ADC();
  start_ADC();
  set_pwm_tmr2(value);
  
  if (estat == positiu){
    if(value<=127-marge){
    	clocks+=1; 
    	estat = negatiu;
    }
  }
  else if (estat == negatiu){
    if (value>127+marge){
      clocks+=1;
      estat = positiu;   
    }
  }

  i++;
  if (i==20000) { 
    i=0;
    printf("clocks=%d\n",clocks/2);
    
    if (clocks>minim){
      // Calculem la frequencia
      frequencia=(uint32_t)inter_freq*(OCR1A-1);
      printf("\n\nfrequencia=%ld\n\n", frequencia);
      // Calculem la diferencia entra el clock real i el clock minim
      minim=0xFFFF;
      // Tornem a ficar el OCR1 a 790
      OCR1A=inici;
    }
    else {
      // Si els clocks no son mes grans que el minims, ara el nou clock minim es el valor actual del clock
      minim=clocks;
      // Augmentem el OCR1A en 1 per canviar al frequencia 
      OCR1A+=1;
      // Si hem arribat al final tornem al inici
      if (OCR1A==final)
  		OCR1A=inici;
      }
  	  clocks=0;
  	}
 PORTD &= ~(1<<PD4);
}
