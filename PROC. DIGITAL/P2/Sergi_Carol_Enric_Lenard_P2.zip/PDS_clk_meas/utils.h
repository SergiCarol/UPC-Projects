#ifndef _AVRUTILS_H
#define _AVRUTILS_H

#define sbi(PORT, BITNO) (PORT |= 1 << BITNO)
#define cbi(PORT, BITNO) (PORT &= ~(1 << BITNO))
#define tbi(PORT, BITNO) (PORT ^= 1 << BITNO)

#endif
