Introducció
===========

Aquesta practica es la practica numero 5 de l'assignatura de *Tecnologies de la programació*.

El programa es basará en realitzar una aplicació que simulará un circuit digital pleestablert definit per l'usuari. 

S'ha de tenir en compte que en aquesta practica es treballaran els asepctes següents:

- Assentar les bases pe a utilizar el gestor de versions *subversion*: Aquest programa serveix per a administrar les versions facilment, i poder fer treballs conjuntament de manera facil i clara. A mes a mes, també permet accedir a versions anteriors, i veure els canvis que hi ha hagut entre elles.

- Treball en equip. Aquest aspecte es molt important treballar, ya que en la majoria de programes es treballa en equip. Això es de molta utilitat perque en el cas de que no es sapiga treballar en equip, un projecte pot arribar a ser un fracas, ja que quan algu cambia algun codi, si hi ha un altre que no ho sap i realitza uns cambis sense tenir en compte lo que abans ha fet el seu company, el "caos" pot arribar a ser molt gran.

- Programació de subclasses: Saber utilizar classes es molt important a l'hora de fer aplicacions amb un cert grau de complexitat. Es basa en heretar els atributs d'una classe a una altre classe.




