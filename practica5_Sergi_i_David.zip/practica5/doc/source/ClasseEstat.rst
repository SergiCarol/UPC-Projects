Classe Estat
============

.. automodule:: estat
    :members:
		
