Modul Supervisor
================

.. automodule:: supervisor
	:members:
