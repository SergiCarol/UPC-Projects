

Documentació : Practica numero 5
================================

Contents:

.. toctree::
   :maxdepth: 2

   Introduccio
   ClasseEstat
   ModulTriport
   ModulSupervisor
   ModulMain



Index
=====

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

